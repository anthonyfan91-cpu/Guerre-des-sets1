# Obtenir l'APK de Guerre des Sets (sans rien installer)

1. Crée un compte gratuit sur github.com, puis un nouveau dépôt (Repository) vide.
2. Clique "uploading an existing file", glisse TOUT le contenu de ce dossier (y compris le dossier `.github`, caché sur certains systèmes : active "afficher les fichiers cachés"), puis "Commit".
3. Onglet **Actions** > "Construire l'APK" > **Run workflow** (la construction démarre aussi toute seule). Compte environ 3 à 6 minutes.
4. Ouvre l'exécution terminée, section **Artifacts** : télécharge **GuerreDesSets-APK** (un zip contenant `app-debug.apk`).
5. Envoie `app-debug.apk` sur le S24, ouvre-le, autorise "Installer des applis inconnues" pour ton navigateur ou ton gestionnaire de fichiers.

Alternative locale : Android Studio > Open ce dossier > Build > Build APK(s).

## Limites
- C'est un APK "debug" signé automatiquement : parfait pour installer et tester sur ton téléphone.
- Le Play Store exige un AAB signé avec ta propre clé (`gradle bundleRelease` + keystore à créer et à garder précieusement) et un compte développeur Google Play.
- Projet non compilé dans mon environnement (pas d'accès au SDK Android) : si la construction échoue, copie-moi l'erreur de l'onglet Actions et je corrige.
- Pour changer le jeu : remplace `app/src/main/assets/index.html` par la nouvelle version.
